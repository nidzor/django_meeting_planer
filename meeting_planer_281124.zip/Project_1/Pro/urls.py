from django.urls import path
from . import views
urlpatterns = [
    path('<int:id>', views.detail, name="detail"),
    path('all_rooms', views.all_rooms, name="all_rooms"),
    path('new', views.new, name='new'),
]
