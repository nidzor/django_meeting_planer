from django.shortcuts import render, get_object_or_404, redirect
from Pro.models import Meeting, Room
from django.forms import modelform_factory

MeetingForm = modelform_factory(Meeting, exclude=[])

def welcome(request):
    return render(request, "welcome.html", {"Metting": Meeting.objects.all()})

def detail(request, id):
    meeting=get_object_or_404(Meeting, pk=id)
    return render(request, "detail.html", {"meeting": meeting})

def all_rooms(request):
    return render(request, "all_rooms.html", {"rooms": Room.objects.all() })

def new(request):
    if request.method == "POST":
        form = MeetingForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("welcome")
    else:
        form = MeetingForm()
    return render(request, "new.html",{"form":form})
