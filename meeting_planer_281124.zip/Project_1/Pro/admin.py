from django.contrib import admin
from Pro.models import Meeting, Room

admin.site.register(Meeting)
admin.site.register(Room)